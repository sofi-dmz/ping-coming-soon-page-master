<?php
/**
 * Uninstall Easy Google Fonts
 *
 * This file is intentionally blank as the plugin
 * admin screen manages any option/transient/data
 * removal.
 *
 * @package easy-google-fonts
 * @author  Sunny Johal - Titanium Themes <support@titaniumthemes.com>
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
