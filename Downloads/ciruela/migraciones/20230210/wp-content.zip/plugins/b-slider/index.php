<?php
/**
 * Plugin Name: B Slider
 * Description: Simple slider with bootstrap.
 * Version: 1.0.7
 * Author: bPlugins LLC
 * Author URI: http://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: slider
 */

// ABS PATH
if ( !defined( 'ABSPATH' ) ) { exit; }

// Constant
define( 'BSB_PLUGIN_VERSION', 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.0.7' );
define( 'BSB_DIR', plugin_dir_url( __FILE__ ) );
define( 'BSB_ASSETS_DIR', plugin_dir_url( __FILE__ ) . 'assets/' );

// Block Directory
class BSBSlider{
	function __construct(){
		add_action( 'enqueue_block_assets', [$this, 'enqueueBlockAssets'] );
		add_action( 'init', [$this, 'onInit'] );
	}

	// Block Reusable and Check block load js/css file 
	function has_reusable_block( $block_name ){
		if( get_the_ID() ){
			if ( has_block( 'block', get_the_ID() ) ){
				// Check reusable blocks
				$content = get_post_field( 'post_content', get_the_ID() );
				$blocks = parse_blocks( $content );
	
				if ( !is_array( $blocks ) || empty( $blocks ) ) {
					return false;
				}
	
				foreach ( $blocks as $block ) {
					if ( $block['blockName'] === 'core/block' && ! empty( $block['attrs']['ref'] ) ) {
						if( has_block( $block_name, $block['attrs']['ref'] ) ){
						 	return true;
						}
					}
				}
			}
		}
		return false;
	}

	function enqueueBlockAssets(){
			 
		wp_register_style( 'bsbfontawesome', BSB_ASSETS_DIR . 'css/fontAwesome.min.css', [], BSB_PLUGIN_VERSION );
		wp_register_style( 'bootstrap', BSB_ASSETS_DIR . 'css/bootstrap.min.css', [], BSB_PLUGIN_VERSION );
		wp_register_script( 'bootstrap', BSB_ASSETS_DIR . 'js/bootstrap.min.js', [], BSB_PLUGIN_VERSION );

		wp_register_script( 'bsb-script', BSB_DIR . 'dist/script.js', ['react', 'react-dom', 'bootstrap'], BSB_PLUGIN_VERSION );
		wp_register_style( 'bsb-style', plugins_url( 'dist/style.css', __FILE__ ), ['bootstrap', 'bsbfontawesome' ], BSB_PLUGIN_VERSION ); // Frontend Style
			
		if( $this->has_reusable_block( 'bsb/slider' ) || has_block( 'bsb/slider', get_the_ID() ) ){
			wp_enqueue_style( 'bsb-style' );
			wp_enqueue_script( 'bsb-script' );
		}

	}

	function onInit() {

		wp_register_style( 'bsb-slider-editor-style', plugins_url( 'dist/editor.css', __FILE__ ), [ 'wp-edit-blocks','bsb-style' ], BSB_PLUGIN_VERSION ); // Backend Style

		register_block_type( __DIR__, [
			'editor_style'		=> 'bsb-slider-editor-style',
			'render_callback'	=> [$this, 'render']
		] ); // Register Block
		wp_set_script_translations( 'bsb-slider-editor-script', 'slider', plugin_dir_path( __FILE__ ) . 'languages' ); // Translate
	}

	function render( $attributes ){
		extract( $attributes );

		$className = $className ?? '';
		$bsbBlockClassName = 'wp-block-bsb-slider ' . $className . ' align' . $align;

		ob_start(); ?>
		<div class='<?php echo esc_attr( $bsbBlockClassName ); ?>' id='bsbCarousel-<?php echo esc_attr( $cId ) ?>' data-attributes='<?php echo esc_attr( wp_json_encode( $attributes ) ); ?>'></div>

		<?php return ob_get_clean();
	} // Render
}
new BSBSlider();